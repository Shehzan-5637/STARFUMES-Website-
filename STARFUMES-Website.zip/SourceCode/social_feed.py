# Your full Python Tkinter code goes here
